
#include <stdio.h>
#include "log.h"
#include <time.h>

void create_log(char *user_name) {
   FILE *fp;
   char c;
   // time_t rawtime;
   // struct tm *info;
   // time( &rawtime );
   // info = localtime( &rawtime );

   fp = fopen("/home/jordan/Desktop/logfile.txt", "w");

   fprintf(fp, "Username: %s\n", user_name);
   //fprintf(fp, "Username: %sDate: %s\n", user_name, asctime(info));
   fclose(fp);

   fp = fopen("/home/jordan/Desktop/logfile.txt", "r");

   printf("LOG FILE\n");
   c = fgetc(fp);
   while (c != EOF) {
    printf("%c", c);
    c = fgetc(fp);
   } 
   fclose(fp);
}